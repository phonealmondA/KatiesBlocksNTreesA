
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.katiesmod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.katiesmod.KatiesmodMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class KatiesmodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, KatiesmodMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(KatiesmodModBlocks.KATIE_FURNACE.get().asItem());
			tabData.accept(KatiesmodModBlocks.PIPE_A.get().asItem());
			tabData.accept(KatiesmodModBlocks.PIPE_GATE.get().asItem());
			tabData.accept(KatiesmodModBlocks.KATIE_WINDOW_A.get().asItem());
			tabData.accept(KatiesmodModItems.KATIE_GLOW_STONE.get());
			tabData.accept(KatiesmodModItems.KATIE_VISION_POTION.get());
			tabData.accept(KatiesmodModItems.KATIE_NETHER_PEARL.get());
			tabData.accept(KatiesmodModItems.KATIE_OVER_WORLD_PEARL.get());
			tabData.accept(KatiesmodModBlocks.KATIE_AUTO_FURNACE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(KatiesmodModBlocks.KATIE_WOOD.get().asItem());
			tabData.accept(KatiesmodModBlocks.KATIE_PLANK.get().asItem());
			tabData.accept(KatiesmodModBlocks.KATIE_AIR_PLANKS.get().asItem());
			tabData.accept(KatiesmodModBlocks.KATIE_AIR_PLANKS_SOLID_STATE.get().asItem());
			tabData.accept(KatiesmodModBlocks.KATIE_AIR_PLANKS_SOLID_REDSTONE_A.get().asItem());
			tabData.accept(KatiesmodModBlocks.KAITIE_AIR_PLANKS_SOLID_REDSTONE_B.get().asItem());
			tabData.accept(KatiesmodModBlocks.KATIE_LEAVES.get().asItem());
			tabData.accept(KatiesmodModBlocks.KATIE_SAPLING.get().asItem());
			tabData.accept(KatiesmodModBlocks.KATIE_WOOD_POWERED.get().asItem());
		}
	}
}
