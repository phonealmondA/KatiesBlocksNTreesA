
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.katiesmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.katiesmod.item.KatieVisionPotionItem;
import net.mcreator.katiesmod.item.KatieOverWorldPearlItem;
import net.mcreator.katiesmod.item.KatieNetherPearlItem;
import net.mcreator.katiesmod.item.KatieGlowStoneItem;
import net.mcreator.katiesmod.KatiesmodMod;

public class KatiesmodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, KatiesmodMod.MODID);
	public static final RegistryObject<Item> KATIE_FURNACE = block(KatiesmodModBlocks.KATIE_FURNACE);
	public static final RegistryObject<Item> PIPE_A = block(KatiesmodModBlocks.PIPE_A);
	public static final RegistryObject<Item> PIPE_GATE = block(KatiesmodModBlocks.PIPE_GATE);
	public static final RegistryObject<Item> KATIE_WOOD = block(KatiesmodModBlocks.KATIE_WOOD);
	public static final RegistryObject<Item> KATIE_PLANK = block(KatiesmodModBlocks.KATIE_PLANK);
	public static final RegistryObject<Item> KATIE_AIR_PLANKS = block(KatiesmodModBlocks.KATIE_AIR_PLANKS);
	public static final RegistryObject<Item> KATIE_AIR_PLANKS_SOLID_STATE = block(KatiesmodModBlocks.KATIE_AIR_PLANKS_SOLID_STATE);
	public static final RegistryObject<Item> KATIE_AIR_PLANKS_SOLID_REDSTONE_A = block(KatiesmodModBlocks.KATIE_AIR_PLANKS_SOLID_REDSTONE_A);
	public static final RegistryObject<Item> KAITIE_AIR_PLANKS_SOLID_REDSTONE_B = block(KatiesmodModBlocks.KAITIE_AIR_PLANKS_SOLID_REDSTONE_B);
	public static final RegistryObject<Item> KATIE_LEAVES = block(KatiesmodModBlocks.KATIE_LEAVES);
	public static final RegistryObject<Item> KATIE_SAPLING = block(KatiesmodModBlocks.KATIE_SAPLING);
	public static final RegistryObject<Item> KATIE_WINDOW_A = block(KatiesmodModBlocks.KATIE_WINDOW_A);
	public static final RegistryObject<Item> KATIE_GLOW_STONE = REGISTRY.register("katie_glow_stone", () -> new KatieGlowStoneItem());
	public static final RegistryObject<Item> KATIE_VISION_POTION = REGISTRY.register("katie_vision_potion", () -> new KatieVisionPotionItem());
	public static final RegistryObject<Item> KATIE_WOOD_POWERED = block(KatiesmodModBlocks.KATIE_WOOD_POWERED);
	public static final RegistryObject<Item> KATIE_NETHER_PEARL = REGISTRY.register("katie_nether_pearl", () -> new KatieNetherPearlItem());
	public static final RegistryObject<Item> KATIE_OVER_WORLD_PEARL = REGISTRY.register("katie_over_world_pearl", () -> new KatieOverWorldPearlItem());
	public static final RegistryObject<Item> KATIE_AUTO_FURNACE = block(KatiesmodModBlocks.KATIE_AUTO_FURNACE);
	public static final RegistryObject<Item> KATIE_ENDER_BLOCK = block(KatiesmodModBlocks.KATIE_ENDER_BLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
