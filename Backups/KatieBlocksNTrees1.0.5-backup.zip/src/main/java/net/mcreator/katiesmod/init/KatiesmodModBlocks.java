
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.katiesmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.katiesmod.block.PipeGateBlock;
import net.mcreator.katiesmod.block.PipeABlock;
import net.mcreator.katiesmod.block.KatieWoodPoweredBlock;
import net.mcreator.katiesmod.block.KatieWoodBlock;
import net.mcreator.katiesmod.block.KatieWindowABlock;
import net.mcreator.katiesmod.block.KatieSaplingBlock;
import net.mcreator.katiesmod.block.KatiePlankBlock;
import net.mcreator.katiesmod.block.KatieLeavesBlock;
import net.mcreator.katiesmod.block.KatieFurnaceBlock;
import net.mcreator.katiesmod.block.KatieEnderBlockBlock;
import net.mcreator.katiesmod.block.KatieAutoFurnaceBlock;
import net.mcreator.katiesmod.block.KatieAirPlanksSolidStateBlock;
import net.mcreator.katiesmod.block.KatieAirPlanksSolidRedstoneABlock;
import net.mcreator.katiesmod.block.KatieAirPlanksBlock;
import net.mcreator.katiesmod.block.KaitieAirPlanksSolidRedstoneBBlock;
import net.mcreator.katiesmod.KatiesmodMod;

public class KatiesmodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, KatiesmodMod.MODID);
	public static final RegistryObject<Block> KATIE_FURNACE = REGISTRY.register("katie_furnace", () -> new KatieFurnaceBlock());
	public static final RegistryObject<Block> PIPE_A = REGISTRY.register("pipe_a", () -> new PipeABlock());
	public static final RegistryObject<Block> PIPE_GATE = REGISTRY.register("pipe_gate", () -> new PipeGateBlock());
	public static final RegistryObject<Block> KATIE_WOOD = REGISTRY.register("katie_wood", () -> new KatieWoodBlock());
	public static final RegistryObject<Block> KATIE_PLANK = REGISTRY.register("katie_plank", () -> new KatiePlankBlock());
	public static final RegistryObject<Block> KATIE_AIR_PLANKS = REGISTRY.register("katie_air_planks", () -> new KatieAirPlanksBlock());
	public static final RegistryObject<Block> KATIE_AIR_PLANKS_SOLID_STATE = REGISTRY.register("katie_air_planks_solid_state", () -> new KatieAirPlanksSolidStateBlock());
	public static final RegistryObject<Block> KATIE_AIR_PLANKS_SOLID_REDSTONE_A = REGISTRY.register("katie_air_planks_solid_redstone_a", () -> new KatieAirPlanksSolidRedstoneABlock());
	public static final RegistryObject<Block> KAITIE_AIR_PLANKS_SOLID_REDSTONE_B = REGISTRY.register("kaitie_air_planks_solid_redstone_b", () -> new KaitieAirPlanksSolidRedstoneBBlock());
	public static final RegistryObject<Block> KATIE_LEAVES = REGISTRY.register("katie_leaves", () -> new KatieLeavesBlock());
	public static final RegistryObject<Block> KATIE_SAPLING = REGISTRY.register("katie_sapling", () -> new KatieSaplingBlock());
	public static final RegistryObject<Block> KATIE_WINDOW_A = REGISTRY.register("katie_window_a", () -> new KatieWindowABlock());
	public static final RegistryObject<Block> KATIE_WOOD_POWERED = REGISTRY.register("katie_wood_powered", () -> new KatieWoodPoweredBlock());
	public static final RegistryObject<Block> KATIE_AUTO_FURNACE = REGISTRY.register("katie_auto_furnace", () -> new KatieAutoFurnaceBlock());
	public static final RegistryObject<Block> KATIE_ENDER_BLOCK = REGISTRY.register("katie_ender_block", () -> new KatieEnderBlockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
