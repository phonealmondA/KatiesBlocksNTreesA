package net.mcreator.katiesmod.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.katiesmod.KatiesmodMod;

public class KatieNetherPortalAProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double yloc = 0;
		double xloc = 0;
		double zloc = 0;
		KatieNetherPortalBProcedure.execute(world, x, y, z);
		KatiesmodMod.queueServerWork(300, () -> {
			KatieNetherPortalCProcedure.execute(world, x, y, z);
		});
	}
}
