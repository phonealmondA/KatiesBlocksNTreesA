package net.mcreator.katiesmod.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.katiesmod.init.KatiesmodModBlocks;
import net.mcreator.katiesmod.KatiesmodMod;

public class KatieVisionPotionEffectEffectStartedappliedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double XLoc = 0;
		double YLoc = 0;
		double ZLoc = 0;
		double repeatA = 0;
		BlockState LookingBlock = Blocks.AIR.defaultBlockState();
		BlockState localBlockA = Blocks.AIR.defaultBlockState();
		XLoc = entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, entity)).getBlockPos().getX();
		YLoc = entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, entity)).getBlockPos().getY();
		ZLoc = entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, entity)).getBlockPos().getZ();
		LookingBlock = (world.getBlockState(BlockPos.containing(XLoc, YLoc, ZLoc)));
		repeatA = 0;
		if (LookingBlock.getBlock() == KatiesmodModBlocks.KATIE_AIR_PLANKS.get()) {
			if (LookingBlock.getBlock() == KatiesmodModBlocks.KATIE_AIR_PLANKS.get()) {
				KatiesmodMod.queueServerWork(5, () -> {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x + 1, y, z);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
				});
				KatiesmodMod.queueServerWork(5, () -> {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x, y, z + 1);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
				});
				KatiesmodMod.queueServerWork(5, () -> {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x, y, z - 1);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
				});
				KatiesmodMod.queueServerWork(5, () -> {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x - 1, y, z);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
				});
				world.setBlock(BlockPos.containing(XLoc, YLoc, ZLoc), KatiesmodModBlocks.KATIE_AIR_PLANKS_SOLID_REDSTONE_A.get().defaultBlockState(), 3);
				repeatA = 0;
				for (int index0 = 0; index0 < 10; index0++) {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x + repeatA, y, z);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
					repeatA = repeatA + 1;
				}
				repeatA = 0;
				for (int index1 = 0; index1 < 10; index1++) {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x, y, z + repeatA);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
					repeatA = repeatA + 1;
				}
				repeatA = 0;
				for (int index2 = 0; index2 < 10; index2++) {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x, y + repeatA, z);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
					repeatA = repeatA + 1;
				}
				repeatA = 0;
				for (int index3 = 0; index3 < 10; index3++) {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x - repeatA, y, z);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
					repeatA = repeatA + 1;
				}
				repeatA = 0;
				for (int index4 = 0; index4 < 10; index4++) {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x, y - repeatA, z);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
					repeatA = repeatA + 1;
				}
				repeatA = 0;
				for (int index5 = 0; index5 < 10; index5++) {
					if (entity instanceof Player _player) {
						BlockPos _bp = BlockPos.containing(x, y, z - repeatA);
						_player.level().getBlockState(_bp).use(_player.level(), _player, InteractionHand.MAIN_HAND, BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
					}
					repeatA = repeatA + 1;
				}
			}
		}
		if (LookingBlock.getBlock() == KatiesmodModBlocks.KATIE_WOOD.get()) {
			world.setBlock(BlockPos.containing(XLoc, YLoc, ZLoc), KatiesmodModBlocks.KATIE_WOOD_POWERED.get().defaultBlockState(), 3);
		}
		if (LookingBlock.getBlock() == KatiesmodModBlocks.KATIE_LEAVES.get()) {
			world.setBlock(BlockPos.containing(XLoc, YLoc, ZLoc), Blocks.AIR.defaultBlockState(), 3);
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, XLoc, YLoc, ZLoc, new ItemStack(Items.REDSTONE));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, XLoc, YLoc, ZLoc, new ItemStack(Items.REDSTONE));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, XLoc, YLoc, ZLoc, new ItemStack(Items.REDSTONE));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
		}
	}
}
