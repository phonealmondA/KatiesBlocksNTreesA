package net.mcreator.katiesmod.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.katiesmod.init.KatiesmodModBlocks;

public class KatieVisionPotionEffectEffectStartedappliedProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		BlockState LookingBlock = Blocks.AIR.defaultBlockState();
		double XLoc = 0;
		double YLoc = 0;
		double ZLoc = 0;
		XLoc = entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, entity)).getBlockPos().getX();
		YLoc = entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, entity)).getBlockPos().getY();
		ZLoc = entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, entity)).getBlockPos().getZ();
		LookingBlock = (world.getBlockState(BlockPos.containing(XLoc, YLoc, ZLoc)));
		if (LookingBlock.getBlock() == KatiesmodModBlocks.KATIE_AIR_PLANKS.get()) {
			world.setBlock(BlockPos.containing(XLoc, YLoc, ZLoc), KatiesmodModBlocks.KATIE_AIR_PLANKS_SOLID_STATE.get().defaultBlockState(), 3);
		}
		if (LookingBlock.getBlock() == KatiesmodModBlocks.KATIE_WOOD.get()) {
			world.setBlock(BlockPos.containing(XLoc, YLoc, ZLoc), KatiesmodModBlocks.KATIE_WOOD_POWERED.get().defaultBlockState(), 3);
		}
		if (LookingBlock.getBlock() == KatiesmodModBlocks.KATIE_LEAVES.get()) {
			world.setBlock(BlockPos.containing(XLoc, YLoc, ZLoc), Blocks.AIR.defaultBlockState(), 3);
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, XLoc, YLoc, ZLoc, new ItemStack(Items.REDSTONE));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, XLoc, YLoc, ZLoc, new ItemStack(Items.REDSTONE));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, XLoc, YLoc, ZLoc, new ItemStack(Items.REDSTONE));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
		}
	}
}
