
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.katiesmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.katiesmod.potion.KatieVisionPotionEffectMobEffect;
import net.mcreator.katiesmod.KatiesmodMod;

public class KatiesmodModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, KatiesmodMod.MODID);
	public static final RegistryObject<MobEffect> KATIE_VISION_POTION_EFFECT = REGISTRY.register("katie_vision_potion_effect", () -> new KatieVisionPotionEffectMobEffect());
}
