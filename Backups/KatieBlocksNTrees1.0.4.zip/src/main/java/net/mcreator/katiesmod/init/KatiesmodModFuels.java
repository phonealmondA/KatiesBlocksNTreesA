
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.katiesmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;

import net.minecraft.world.item.ItemStack;

@Mod.EventBusSubscriber
public class KatiesmodModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		ItemStack itemstack = event.getItemStack();
		if (itemstack.getItem() == KatiesmodModBlocks.KATIE_WOOD.get().asItem())
			event.setBurnTime(3000);
		else if (itemstack.getItem() == KatiesmodModBlocks.KATIE_PLANK.get().asItem())
			event.setBurnTime(800);
		else if (itemstack.getItem() == KatiesmodModBlocks.KATIE_AIR_PLANKS.get().asItem())
			event.setBurnTime(200);
	}
}
