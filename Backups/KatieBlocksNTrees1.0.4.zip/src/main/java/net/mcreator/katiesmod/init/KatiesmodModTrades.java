
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.katiesmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class KatiesmodModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.FARMER) {
			event.getTrades().get(1)
					.add(new BasicItemListing(new ItemStack(KatiesmodModBlocks.KATIE_AIR_PLANKS.get(), 48), new ItemStack(KatiesmodModBlocks.KATIE_PLANK.get(), 6), new ItemStack(KatiesmodModItems.KATIE_NETHER_PEARL.get(), 2), 100, 50, 0.0005f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(KatiesmodModBlocks.KATIE_WOOD.get(), 8), new ItemStack(KatiesmodModBlocks.KATIE_SAPLING.get(), 3), new ItemStack(Blocks.RAW_IRON_BLOCK), 100, 50, 0.05f));
			event.getTrades().get(3)
					.add(new BasicItemListing(new ItemStack(KatiesmodModBlocks.KATIE_WOOD.get(), 2), new ItemStack(KatiesmodModBlocks.KATIE_PLANK.get(), 12), new ItemStack(KatiesmodModItems.KATIE_VISION_POTION.get(), 64), 10, 40, 0.05f));
			event.getTrades().get(1)
					.add(new BasicItemListing(new ItemStack(KatiesmodModItems.KATIE_NETHER_PEARL.get()), new ItemStack(KatiesmodModBlocks.KATIE_WOOD.get(), 16), new ItemStack(KatiesmodModItems.KATIE_OVER_WORLD_PEARL.get(), 16), 10, 50, 0.05f));
			event.getTrades().get(5).add(new BasicItemListing(new ItemStack(Items.IRON_INGOT, 6),

					new ItemStack(KatiesmodModBlocks.KATIE_SAPLING.get(), 6), 10, 5, 0.05f));
		}
	}
}
