package net.mcreator.katiesmod.procedures;

import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.katiesmod.KatiesmodMod;

public class KatieAirPlanksSolidStateRedstoneOnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		double numbA = 0;
		double localredstonelvl = 0;
		double ylower = 0;
		double localRedWest = 0;
		localredstonelvl = world instanceof Level _lvl_getRedPow ? _lvl_getRedPow.getSignal(BlockPos.containing(x, y, z), Direction.EAST) : 0;
		localRedWest = world instanceof Level _lvl_getRedPow ? _lvl_getRedPow.getSignal(BlockPos.containing(x, y, z), Direction.WEST) : 0;
		numbA = blockstate.getBlock().getStateDefinition().getProperty("redstonelevel") instanceof IntegerProperty _getip3 ? blockstate.getValue(_getip3) : -1;
		if (localredstonelvl > 0) {
			if (world instanceof Level _level4 && _level4.hasNeighborSignal(BlockPos.containing(x + 1, y, z))) {
				{
					int _value = 1;
					BlockPos _pos = BlockPos.containing(x - 1, y, z);
					BlockState _bs = world.getBlockState(_pos);
					if (_bs.getBlock().getStateDefinition().getProperty("redstonelevel") instanceof IntegerProperty _integerProp && _integerProp.getPossibleValues().contains(_value))
						world.setBlock(_pos, _bs.setValue(_integerProp, _value), 3);
				}
				KatiesmodMod.queueServerWork(40, () -> {
					KatieAirPlankRedstoneOffBProcedure.execute(world, x, y, z);
				});
			}
		}
	}
}
