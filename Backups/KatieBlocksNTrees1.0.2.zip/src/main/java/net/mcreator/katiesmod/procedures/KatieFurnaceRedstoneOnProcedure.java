package net.mcreator.katiesmod.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.katiesmod.KatiesmodMod;

public class KatieFurnaceRedstoneOnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		KatiesmodMod.queueServerWork(20, () -> {
			KatieFurnacePunchStartProcedure.execute(world, x, y, z);
		});
	}
}
