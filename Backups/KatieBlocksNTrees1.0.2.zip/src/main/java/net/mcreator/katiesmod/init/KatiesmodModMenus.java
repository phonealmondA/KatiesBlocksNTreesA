
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.katiesmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.katiesmod.world.inventory.KatiePoweredPlankAMenu;
import net.mcreator.katiesmod.world.inventory.KatieFurnaceGUIMenu;
import net.mcreator.katiesmod.KatiesmodMod;

public class KatiesmodModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, KatiesmodMod.MODID);
	public static final RegistryObject<MenuType<KatieFurnaceGUIMenu>> KATIE_FURNACE_GUI = REGISTRY.register("katie_furnace_gui", () -> IForgeMenuType.create(KatieFurnaceGUIMenu::new));
	public static final RegistryObject<MenuType<KatiePoweredPlankAMenu>> KATIE_POWERED_PLANK_A = REGISTRY.register("katie_powered_plank_a", () -> IForgeMenuType.create(KatiePoweredPlankAMenu::new));
}
