package net.mcreator.katiesmod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.katiesmod.init.KatiesmodModBlocks;

public class KatieAirPlanksNeighbourBlockChangesRedstoneProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world instanceof Level _lvl_getRedPow ? _lvl_getRedPow.getSignal(BlockPos.containing(x, y, z), Direction.EAST) : 0) > 0) {
			world.setBlock(BlockPos.containing(x, y, z), KatiesmodModBlocks.KATIE_SOLID_STATE_KEST.get().defaultBlockState(), 3);
		}
	}
}
