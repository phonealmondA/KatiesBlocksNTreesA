package net.mcreator.katiesmod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.katiesmod.init.KatiesmodModParticleTypes;

public class KatieAirPlanksSolidRedstoneAOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (KatiesmodModParticleTypes.KATIE_PARTICAL_A.get()), x, y, z, 5, 2, 2, 2, 0.5);
	}
}
