
package net.mcreator.katiesmod.potion;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.katiesmod.procedures.KatieVisionPotionEffectEffectappliedProcedure;
import net.mcreator.katiesmod.procedures.KatieVisionPotionEffectEffectStartedappliedProcedure;
import net.mcreator.katiesmod.init.KatiesmodModAttributes;

import java.util.List;
import java.util.ArrayList;

public class KatieVisionPotionEffectMobEffect extends MobEffect {
	public KatieVisionPotionEffectMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -1);
		this.addAttributeModifier(KatiesmodModAttributes.KATIE_VISION.get(), "4aebbd67-0740-34ee-9ff4-28b1b3c15991", 3.98, AttributeModifier.Operation.ADDITION);
	}

	@Override
	public boolean isInstantenous() {
		return true;
	}

	@Override
	public List<ItemStack> getCurativeItems() {
		ArrayList<ItemStack> cures = new ArrayList<ItemStack>();
		return cures;
	}

	@Override
	public void applyInstantenousEffect(Entity source, Entity indirectSource, LivingEntity entity, int amplifier, double health) {
		KatieVisionPotionEffectEffectappliedProcedure.execute(entity);
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		KatieVisionPotionEffectEffectStartedappliedProcedure.execute(entity.level(), entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
