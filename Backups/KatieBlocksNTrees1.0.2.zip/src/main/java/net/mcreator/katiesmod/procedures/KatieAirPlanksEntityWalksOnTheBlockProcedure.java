package net.mcreator.katiesmod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.katiesmod.init.KatiesmodModBlocks;

public class KatieAirPlanksEntityWalksOnTheBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		world.setBlock(BlockPos.containing(x, y, z), KatiesmodModBlocks.KATIE_PLANK_SOLID_DIRECTIONAL.get().defaultBlockState(), 3);
	}
}
