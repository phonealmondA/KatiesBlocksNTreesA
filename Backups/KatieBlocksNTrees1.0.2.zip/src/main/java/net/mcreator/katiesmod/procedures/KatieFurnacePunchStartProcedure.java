package net.mcreator.katiesmod.procedures;

import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.SimpleContainer;
import net.minecraft.core.BlockPos;

import java.util.concurrent.atomic.AtomicReference;

public class KatieFurnacePunchStartProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		ItemStack InputSlot2 = ItemStack.EMPTY;
		ItemStack InputSlot = ItemStack.EMPTY;
		ItemStack OutputSlot = ItemStack.EMPTY;
		double SlotcAmount = 0;
		double SlotAamount = 0;
		InputSlot = (new Object() {
			public ItemStack getItemStack(LevelAccessor world, BlockPos pos, int slotid) {
				AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
				BlockEntity _ent = world.getBlockEntity(pos);
				if (_ent != null)
					_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).copy()));
				return _retval.get();
			}
		}.getItemStack(world, BlockPos.containing(x, y, z), 0)).copy();
		InputSlot2 = (new Object() {
			public ItemStack getItemStack(LevelAccessor world, BlockPos pos, int slotid) {
				AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
				BlockEntity _ent = world.getBlockEntity(pos);
				if (_ent != null)
					_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).copy()));
				return _retval.get();
			}
		}.getItemStack(world, BlockPos.containing(x, y, z), 1)).copy();
		if ((world instanceof Level _level2 && _level2.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(InputSlot), _level2).isPresent()) == true
				|| (world instanceof Level _level3 && _level3.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(InputSlot2), _level3).isPresent()) == true) {
			KatieFurnaceSmeltOneProcedure.execute(world, x, y, z);
		}
		if ((world instanceof Level _level4 && _level4.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(InputSlot), _level4).isPresent()) == true
				&& (world instanceof Level _level5 && _level5.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(InputSlot2), _level5).isPresent()) == true && InputSlot.getItem() == InputSlot2.getItem()) {
			KatieFurnaceSmeltTwoProcedure.execute(world, x, y, z);
		}
	}
}
