package net.mcreator.katiesmod.procedures;

import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;

public class KatieAirPlanksSolidStateEmittedRedstonePowerProcedure {
	public static double execute(BlockState blockstate) {
		boolean RedstoneContinue = false;
		double redstonePower = 0;
		double returnnumberA = 0;
		returnnumberA = blockstate.getBlock().getStateDefinition().getProperty("redstonelevel") instanceof IntegerProperty _getip1 ? blockstate.getValue(_getip1) : -1;
		return returnnumberA;
	}
}
