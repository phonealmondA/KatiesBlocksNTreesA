package net.mcreator.katiesmod.procedures;

import net.minecraft.world.item.ItemStack;

public class KatieFurnacePunchStartProcedure {
	public static void execute() {
		ItemStack InputSlot2 = ItemStack.EMPTY;
		ItemStack InputSlot = ItemStack.EMPTY;
		ItemStack OutputSlot = ItemStack.EMPTY;
		double SlotcAmount = 0;
		double SlotAamount = 0;
	}
}
